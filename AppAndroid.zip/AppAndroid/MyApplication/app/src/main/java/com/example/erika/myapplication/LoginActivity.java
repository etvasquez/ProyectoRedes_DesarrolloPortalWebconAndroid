package com.example.erika.myapplication;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.erika.myapplication.rest.ApiRest;
import com.example.erika.myapplication.rest.DatosIniciales;
import com.example.erika.myapplication.rest.Reporte;
import com.example.erika.myapplication.rest.RestCliente;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    private EditText txtUsuario, txtClave;
    private Button btnLogin;
    public static Context contexto;
    private ProgressDialog progress;
    public static String user;
    public static String contr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        LoginActivity.contexto = getApplicationContext();
        InicializarVariables();
        progress = new ProgressDialog(LoginActivity.this);
        btnLogin.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               progress.setMessage("Espere por favor...");
               progress.setTitle("Cargando Datos");
               progress.setCancelable(false);
               progress.show();
               user = String.valueOf(txtUsuario.getText());
               contr = String.valueOf(txtClave.getText());
               obtenerProducto(user, contr);

            }
        });
        }

    public void obtenerProducto(final String usuario, final String contrasenia) {
        ApiRest cliente = null;
        try {
            Log.i("apisofia", "caso 1 ");
            cliente = RestCliente.cliente(ApiRest.class, this, usuario, contrasenia);
        } catch (Exception e) {
            progress.dismiss();
        }
        ////DISPONIBLES////
        final Call<DatosIniciales> conf_productoD = cliente.obtenerProductosDisponibles();
        conf_productoD.enqueue(new Callback<DatosIniciales>() {
            @Override
            public void onResponse(Call<DatosIniciales> call, Response<DatosIniciales> response) {
                int statusCode = response.code();
                if (statusCode == 200) {
                    try {
                        DatosIniciales infoItem = response.body();
                        if(infoItem!=null){
                           TabDisponibles.datos = infoItem;
                            TabDisponibles.usuario=user;
                            TabDisponibles.clave = contr;
                            Intent intent = new Intent(LoginActivity.this, TabsContenedor.class);
                            startActivity(intent);
                            progress.dismiss();
                        }else {
                            CharSequence text = "Usuario no registrado";
                            int duracion = Toast.LENGTH_LONG;
                            Context context = getApplicationContext();
                            Toast toast = Toast.makeText(context,text,duracion);
                            progress.dismiss();
                            toast.show();
                        }
                    } catch (Exception e) {
                        progress.dismiss();
                    }
                }
            }

            @Override
            public void onFailure(Call<DatosIniciales> call, Throwable t) {
                Log.e("sinconexion", "Falla conexión", t);
                CharSequence text = "No existe conexión revise los parámetros y vuelva a ingresar";
                int duracion = Toast.LENGTH_LONG;
                Context context = getApplicationContext();
                Toast toast = Toast.makeText(context,text,duracion);
                progress.dismiss();
                toast.show();
            }
        });
        /////AGOTADOS/////
        final Call<DatosIniciales> conf_productoA = cliente.obtenerProductosAgotados();
        conf_productoA.enqueue(new Callback<DatosIniciales>() {
            @Override
            public void onResponse(Call<DatosIniciales> call, Response<DatosIniciales> response) {
                int statusCode = response.code();
                if (statusCode == 200) {
                    try {
                        DatosIniciales infoItem = response.body();
                        if(infoItem!=null){
                            TabAgotados.datos = infoItem;
                            TabAgotados.usuario=user;
                            TabAgotados.clave = contr;
                            progress.dismiss();
                        }else {
                            progress.dismiss();
                        }
                    } catch (Exception e) {
                        progress.dismiss();
                    }
                }
            }

            @Override
            public void onFailure(Call<DatosIniciales> call, Throwable t) {
                Log.e("sinconexion", "Falla conección", t);
                progress.dismiss();
            }
        });
        ////CADUCADOS
        final Call<DatosIniciales> conf_productoC = cliente.obtenerProductosCaducados();
        conf_productoC.enqueue(new Callback<DatosIniciales>() {
            @Override
            public void onResponse(Call<DatosIniciales> call, Response<DatosIniciales> response) {
                int statusCode = response.code();
                if (statusCode == 200) {
                    try {
                        DatosIniciales infoItem = response.body();
                        if(infoItem!=null){
                            TabCaducados.datos = infoItem;
                            TabCaducados.usuario=user;
                            TabCaducados.clave = contr;
                            progress.dismiss();
                        }else {
                            progress.dismiss();
                        }

                    } catch (Exception e) {
                        progress.dismiss();
                    }
                }
            }

            @Override
            public void onFailure(Call<DatosIniciales> call, Throwable t) {
                Log.e("sinconexion", "Falla conección", t);
                progress.dismiss();

            }
        });
        ////MAS VENDIDO
        final Call<String> conf_productoMas = cliente.obtenerProductosMas();
        conf_productoMas.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                int statusCode = response.code();
                Log.i("Código de respuesta ","llega");
                if (statusCode == 200) {
                    try {
                        String infoItem = response.body();
                        if(infoItem!=null){
                            TabResultados.datos1 = infoItem;
                            TabResultados.usuario=user;
                            TabResultados.clave = contr;
                            progress.dismiss();
                        }else {
                            progress.dismiss();
                        }

                    } catch (Exception e) {
                        progress.dismiss();
                    }
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                progress.dismiss();
            }

        });
        ////MENOS VENDIDO
        final Call<String> conf_productoMenos = cliente.obtenerProductoMenos();
        conf_productoMenos.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                int statusCode = response.code();
                Log.i("Código de respuesta ","llega");
                if (statusCode == 200) {
                    try {
                        String infoItem = response.body();
                        if(infoItem!=null){
                            TabResultados.datos2 = infoItem;
                            Log.i("DATOS MAS: ",infoItem);
                            progress.dismiss();
                        }else {
                            progress.dismiss();
                        }

                    } catch (Exception e) {
                        progress.dismiss();
                    }
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                progress.dismiss();
            }

        });
        ////GANANCIAS
        final Call<String> conf_productoGanancia = cliente.obtenerProductoGanancia();
        conf_productoGanancia.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                int statusCode = response.code();
                Log.i("Código de respuesta ","llega");
                if (statusCode == 200) {
                    try {
                        String infoItem = response.body();
                        if(infoItem!=null){
                            TabResultados.datos3 = infoItem;
                            Log.i("DATOS MAS: ",infoItem);
                            progress.dismiss();
                        }else {
                            progress.dismiss();
                        }

                    } catch (Exception e) {
                        progress.dismiss();
                    }
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                progress.dismiss();
            }

        });

    }
    private void InicializarVariables () {
        txtUsuario = (EditText) findViewById(R.id.txtUsuario);
        txtClave = (EditText) findViewById(R.id.txtClave);
        btnLogin = (Button) findViewById(R.id.iniciarSesion);
    }
}