package com.example.erika.myapplication;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.erika.myapplication.rest.RestCliente;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    EditText url = null;
    // Patron validar ip
    private static final Pattern IP_ADDRESS
            = Pattern.compile(
            "((25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[1-9])\\.(25[0-5]|2[0-4]"
                    + "[0-9]|[0-1][0-9]{2}|[1-9][0-9]|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]"
                    + "[0-9]{2}|[1-9][0-9]|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}"
                    + "|[1-9][0-9]|[0-9]))");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn = (Button) findViewById(R.id.btninicio);
        url   = (EditText)findViewById(R.id.txturl);
        url.setText("http://");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String texturl =  String.valueOf(url.getText().toString());
                if(texturl.equals("http://")){
                    CharSequence text = "IP INVÁLIDA";
                    int duracion = Toast.LENGTH_LONG;
                    Context context = getApplicationContext();
                    Toast toast = Toast.makeText(context,text,duracion);
                    toast.show();
                }else{
                    Matcher matcher = IP_ADDRESS.matcher(texturl.substring(7));
                    if (matcher.matches()) {
                        RestCliente.puerto = texturl;
                        Intent intent = new Intent (v.getContext(), LoginActivity.class);
                        startActivity(intent);
                        finish();
                    }else{
                        CharSequence text = "IP INVÁLIDA";
                        int duracion = Toast.LENGTH_LONG;
                        Context context = getApplicationContext();
                        Toast toast = Toast.makeText(context,text,duracion);
                        toast.show();
                    }
                }
            }
        });
    }

}
