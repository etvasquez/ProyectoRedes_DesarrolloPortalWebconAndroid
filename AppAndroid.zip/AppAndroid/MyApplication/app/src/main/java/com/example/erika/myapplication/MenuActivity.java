package com.example.erika.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.erika.myapplication.rest.ApiRest;
import com.example.erika.myapplication.rest.DatosIniciales;
import com.example.erika.myapplication.rest.RestCliente;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MenuActivity extends AppCompatActivity {
    private EditText txtUsuario, txtClave;
    private Button btnLogin;
    public static Context contexto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        MenuActivity.contexto = getApplicationContext();
        InicializarVariables();
        btnLogin.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
              String usuario = String.valueOf(txtUsuario.getText());
              String clave = String.valueOf(txtClave.getText());
              obtenerProducto(usuario, clave);
               /*Intent intent = new Intent(LoginActivity.contexto, TabsContenedor.class);
               startActivity(intent);*/
            }
        });
        }

    public void obtenerProducto(String usuario, String contrasenia) {
        ApiRest cliente = null;
        try {
            Log.i("apisofia", "caso 1 ");
            cliente = RestCliente.cliente(ApiRest.class, this, usuario, contrasenia);
        } catch (Exception e) {
            //progress.dismiss();
        }
        ////DISPONIBLES////
        final Call<DatosIniciales> conf_productoD = cliente.obtenerProductosDisponibles();
        conf_productoD.enqueue(new Callback<DatosIniciales>() {
            @Override
            public void onResponse(Call<DatosIniciales> call, Response<DatosIniciales> response) {
                int statusCode = response.code();
                // Log.i(TAG, "Código de respuesta " + statusCode);
                if (statusCode == 200) {
                    try {
                        DatosIniciales infoItem = response.body();
                        if(infoItem!=null){
                           TabDisponibles.datos = infoItem;
                            Intent intent = new Intent(MenuActivity.this, TabsContenedor.class);
                            startActivity(intent);
                        }else {
                            CharSequence text = "Usuario no registrado";
                            int duracion = Toast.LENGTH_LONG;
                            Context context = getApplicationContext();
                            Toast toast = Toast.makeText(context,text,duracion);
                            toast.show();
                        }
                    } catch (Exception e) {
                    }
                }
            }

            @Override
            public void onFailure(Call<DatosIniciales> call, Throwable t) {
                Log.e("sinconexion", "Falla conexión", t);
                CharSequence text = "No existe conexión revise los parámetros y vuelva a ingresar";
                int duracion = Toast.LENGTH_LONG;
                Context context = getApplicationContext();
                Toast toast = Toast.makeText(context,text,duracion);
                toast.show();
            }
        });
        /////AGOTADOS/////
        final Call<DatosIniciales> conf_productoA = cliente.obtenerProductosAgotados();
        conf_productoA.enqueue(new Callback<DatosIniciales>() {
            @Override
            public void onResponse(Call<DatosIniciales> call, Response<DatosIniciales> response) {
                int statusCode = response.code();
                // Log.i(TAG, "Código de respuesta " + statusCode);
                if (statusCode == 200) {
                    try {
                        DatosIniciales infoItem = response.body();
                        if(infoItem!=null){
                            TabAgotados.datos = infoItem;
                            //Intent intent = new Intent(LoginActivity.this, TabsContenedor.class);
                           // startActivity(intent);
                        }else {
                            //mensaje de error
                        }

                    } catch (Exception e) {
                    }
                }
            }

            @Override
            public void onFailure(Call<DatosIniciales> call, Throwable t) {
                Log.e("sinconexion", "Falla conección", t);
                // Mensaje("No existe conección revise los paramentoros y vuelva a ingresar", "ERROR");

            }
        });

        ////CADUCADOS
        final Call<DatosIniciales> conf_productoC = cliente.obtenerProductosCaducados();
        conf_productoC.enqueue(new Callback<DatosIniciales>() {
            @Override
            public void onResponse(Call<DatosIniciales> call, Response<DatosIniciales> response) {
                int statusCode = response.code();
                // Log.i(TAG, "Código de respuesta " + statusCode);
                if (statusCode == 200) {
                    try {
                        DatosIniciales infoItem = response.body();
                        if(infoItem!=null){
                            TabCaducados.datos = infoItem;
                            //Intent intent = new Intent(LoginActivity.this, TabsContenedor.class);
                           // startActivity(intent);
                        }else {
                            //mensaje de error
                        }

                    } catch (Exception e) {
                    }
                }
            }

            @Override
            public void onFailure(Call<DatosIniciales> call, Throwable t) {
                Log.e("sinconexion", "Falla conección", t);
                // Mensaje("No existe conección revise los paramentoros y vuelva a ingresar", "ERROR");

            }
        });
    }
    private void InicializarVariables () {
        txtUsuario = (EditText) findViewById(R.id.txtUsuario);
        txtClave = (EditText) findViewById(R.id.txtClave);
        btnLogin = (Button) findViewById(R.id.iniciarSesion);
    }
}