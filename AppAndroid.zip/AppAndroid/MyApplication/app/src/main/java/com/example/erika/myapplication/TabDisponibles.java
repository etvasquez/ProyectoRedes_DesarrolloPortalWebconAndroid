package com.example.erika.myapplication;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.erika.myapplication.rest.ApiRest;
import com.example.erika.myapplication.rest.DatosIniciales;
import com.example.erika.myapplication.rest.Producto;
import com.example.erika.myapplication.rest.RestCliente;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class TabDisponibles extends Fragment{
    public static DatosIniciales datos;
    private ListView listapro;
    private ProgressDialog progress;
    public static String usuario;
    public static String clave;
     @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
         View v = inflater.inflate(R.layout.activity_tabdisponible,container,false);
         progress = new ProgressDialog(TabDisponibles.this.getActivity());
         obtenerProducto(usuario,clave);
         listapro = (ListView) v.findViewById(R.id.lista_productos);
         ArrayList<Producto> lista = datos.getListpro();
         TabDisponibles.DatosInicialesAdapter adapter = new TabDisponibles.DatosInicialesAdapter(getActivity(), R.layout.list_view_lista_productos, lista);
         listapro.setAdapter(adapter);
        return v;
    }

    private class DatosInicialesAdapter extends ArrayAdapter<Producto> {
        private ArrayList<Producto> items;

        public DatosInicialesAdapter(Context context, int textViewResourceId,
                                     ArrayList<Producto> items) {
            super(context, textViewResourceId, items);
            this.items = items;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            View v = convertView;
            if (v == null) {
                LayoutInflater vi = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                v = vi.inflate(R.layout.list_view_lista_productos, null);
            }

            Producto datosIniciales = items.get(position);

            if (datosIniciales != null) {

                TextView txt_nombre = (TextView) v.findViewById(R.id.lbl_nombre);
                TextView txt_cantidad = (TextView) v.findViewById(R.id.lbl_cantidad);
                TextView txt_estado = (TextView) v.findViewById(R.id.lbl_estado);

                if (txt_nombre != null) {
                    txt_nombre.setText(datosIniciales.getNombre());
                }

                if (txt_cantidad != null) {
                    txt_cantidad.setText(String.valueOf(datosIniciales.getCantidadStock()));
                }
                if (txt_estado != null) {
                    txt_estado.setText(datosIniciales.getIdestado().getEstado());
                }
            }

            return v;
        }
    }

    public void obtenerProducto(String usuario, String contrasenia) {
        Log.i("tabs disponibles: ","Servicio Tas Disponibles" );
        ApiRest cliente = null;
        try {
            progress.setMessage("Espere por favor...");
            progress.setTitle("Cargando Datos");
            progress.setCancelable(false);
            progress.show();
            cliente = RestCliente.cliente(ApiRest.class, LoginActivity.contexto, usuario, contrasenia);
        } catch (Exception e) {
            progress.dismiss();
        }
        ////DISPONIBLES////
        final Call<DatosIniciales> conf_productoD = cliente.obtenerProductosDisponibles();
        conf_productoD.enqueue(new Callback<DatosIniciales>() {
            @Override
            public void onResponse(Call<DatosIniciales> call, Response<DatosIniciales> response) {
                int statusCode = response.code();
                Log.i("Esto es: ", "sii");
                if (statusCode == 200) {
                    try {
                        DatosIniciales infoItem = response.body();
                        if(infoItem!=null){
                            datos = infoItem;
                            progress.dismiss();
                        }else {
                            CharSequence text = "Usuario no registrado";
                            int duracion = Toast.LENGTH_LONG;
                            Context context = getActivity();
                            Toast toast = Toast.makeText(context,text,duracion);
                            progress.dismiss();
                            toast.show();
                        }
                    } catch (Exception e) {
                        progress.dismiss();
                    }
                }
            }

            @Override
            public void onFailure(Call<DatosIniciales> call, Throwable t) {
                Log.e("sinconexion", "Falla conexión", t);
                CharSequence text = "No existe conexión revise los parámetros y vuelva a ingresar";
                int duracion = Toast.LENGTH_LONG;
                Context context = getActivity();
                Toast toast = Toast.makeText(context,text,duracion);
                toast.show();
            }
        });
    }

}
