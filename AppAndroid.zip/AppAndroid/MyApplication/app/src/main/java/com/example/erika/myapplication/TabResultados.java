package com.example.erika.myapplication;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.erika.myapplication.rest.ApiRest;
import com.example.erika.myapplication.rest.DatosIniciales;
import com.example.erika.myapplication.rest.Producto;
import com.example.erika.myapplication.rest.Reporte;
import com.example.erika.myapplication.rest.RestCliente;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class TabResultados extends Fragment{
    public static String datos1;
    public static String datos2;
    public static String datos3;
    public static String usuario;
    public static String clave;
    private ProgressDialog progress;
     @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
         View v = inflater.inflate(R.layout.activity_tabdetalleproducto,container,false);
//         obtenerProducto(usuario,clave);
         TextView txt_mas = (TextView) v.findViewById(R.id.txtmas);
         txt_mas.setText(datos1);
         TextView txt_menos = (TextView) v.findViewById(R.id.txt_menos);
         txt_menos.setText(datos2);
         TextView txt_ga = (TextView) v.findViewById(R.id.txt_ganancia);
         txt_ga.setText(datos3);
        return v;
    }


    public void obtenerProducto(String usuario, String contrasenia) {
        ApiRest cliente = null;
        try {
            Log.i("Esto es: ", usuario);
            progress.setMessage("Espere por favor...");
            progress.setTitle("Cargando Datos");
            progress.setCancelable(false);
            progress.show();
            cliente = RestCliente.cliente(ApiRest.class, LoginActivity.contexto, usuario, contrasenia);
        } catch (Exception e) {
            progress.dismiss();
        }
        ////GANANCIAS
        final Call<String> conf_productoGanancia = cliente.obtenerProductoGanancia();
        conf_productoGanancia.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                int statusCode = response.code();
                Log.i("Código de respuesta ","llega");
                if (statusCode == 200) {
                    try {
                        String infoItem = response.body();
                        if(infoItem!=null){
                            TabResultados.datos3 = infoItem;
                            Log.i("DATOS MAS: ",infoItem);
                            progress.dismiss();
                        }else {
                            progress.dismiss();
                        }

                    } catch (Exception e) {
                        progress.dismiss();
                    }
                }
            }
            @Override
            public void onFailure(Call<String> call, Throwable t) {
                progress.dismiss();
            }

        });
    }
}
