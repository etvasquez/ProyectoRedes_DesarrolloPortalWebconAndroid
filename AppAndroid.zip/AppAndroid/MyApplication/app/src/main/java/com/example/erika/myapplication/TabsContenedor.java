package com.example.erika.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.example.erika.myapplication.rest.ApiRest;
import com.example.erika.myapplication.rest.DatosIniciales;
import com.example.erika.myapplication.rest.Producto;
import com.example.erika.myapplication.rest.Reporte;
import com.example.erika.myapplication.rest.RestCliente;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TabsContenedor extends AppCompatActivity {
    //public  static DatosIniciales datos;
   // public  static Reporte datos1;
    private ListView listapro;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tabcontenedor);
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        viewPager = (ViewPager) findViewById(R.id.viewPager);
        tabLayout.setupWithViewPager(viewPager);
        setUpViewPager(viewPager);
    }

    private void setUpViewPager(ViewPager viewPager){
        TabViewPagerAdapter tabViewPagerAdapter = new TabViewPagerAdapter(getSupportFragmentManager());
        tabViewPagerAdapter.addFrafment(new TabDisponibles(),"Disponibles");
        tabViewPagerAdapter.addFrafment(new TabAgotados(),"Agotados");
        tabViewPagerAdapter.addFrafment(new TabCaducados(), "Caducados");
        tabViewPagerAdapter.addFrafment(new TabResultados(), "Ventas");
        viewPager.setAdapter(tabViewPagerAdapter);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.login_activity, menu);
        return true;
    }


    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.cambiar_url:
                Intent intent2 = new Intent(TabsContenedor.this, LoginActivity.class);
                startActivity(intent2);

                return true;
            case R.id.salir:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}

