package com.example.erika.myapplication.rest;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiRest {

    String URL_CONSULTA_PRODUCTOSDISPOBIBLES = "disponible";
    String URL_CONSULTA_PRODUCTOSAGOTADOS = "agotado";
    String URL_CONSULTA_PRODUCTOSCADUCADOS = "caducado";
    String URL_CONSULTA_PRODUCTOSMAS = "productomas";
    String URL_CONSULTA_PRODUCTOSMENOS = "productomenos";
    String URL_CONSULTA_PRODUCTOSGANANCIA = "ganancia";


    @GET(URL_CONSULTA_PRODUCTOSDISPOBIBLES)
    Call<DatosIniciales> obtenerProductosDisponibles();

    @GET(URL_CONSULTA_PRODUCTOSAGOTADOS)
    Call<DatosIniciales> obtenerProductosAgotados();

    @GET(URL_CONSULTA_PRODUCTOSCADUCADOS)
    Call<DatosIniciales> obtenerProductosCaducados();

    @GET(URL_CONSULTA_PRODUCTOSMAS)
    Call<String> obtenerProductosMas();

    @GET(URL_CONSULTA_PRODUCTOSMENOS)
    Call<String> obtenerProductoMenos();

    @GET(URL_CONSULTA_PRODUCTOSGANANCIA)
    Call<String> obtenerProductoGanancia();
}
