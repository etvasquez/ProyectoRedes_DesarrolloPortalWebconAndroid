package com.example.erika.myapplication.rest;

public class Categoria {
    private int idcategoria;
    private String tipo;

    public Categoria() {
    }

    public Categoria(int idcategoria, String tipo) {
        this.idcategoria = idcategoria;
        this.tipo = tipo;
    }

    public int getIdcategoria() {
        return idcategoria;
    }

    public void setIdcategoria(int idcategoria) {
        this.idcategoria = idcategoria;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
