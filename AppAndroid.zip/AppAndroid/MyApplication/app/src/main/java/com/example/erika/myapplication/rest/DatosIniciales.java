package com.example.erika.myapplication.rest;

import java.util.ArrayList;
import java.util.List;

public class DatosIniciales {
    Proveedor pro = null;
    ArrayList<Producto> listpro= null;

    public DatosIniciales() {
    }
    public DatosIniciales(Proveedor pro,ArrayList<Producto> listpro) {
        this.pro = pro;
        this.listpro = listpro;
    }
    public Proveedor getPro() {
        return pro;
    }

    public void setPro(Proveedor pro) {
        this.pro = pro;
    }

    public ArrayList<Producto> getListpro() {
        return listpro;
    }

    public void setListpro(ArrayList<Producto> listpro) {
        this.listpro = listpro;
    }
}
