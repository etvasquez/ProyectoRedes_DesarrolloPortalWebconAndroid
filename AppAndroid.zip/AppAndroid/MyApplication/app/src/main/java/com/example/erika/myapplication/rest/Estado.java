package com.example.erika.myapplication.rest;

public class Estado {
        private int idestado;
        private String estado;

    public Estado() {
    }

    public Estado(int idestado, String estado) {
        this.idestado = idestado;
        this.estado = estado;
    }

    public int getIdestado() {
        return idestado;
    }

    public void setIdestado(int idestado) {
        this.idestado = idestado;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
