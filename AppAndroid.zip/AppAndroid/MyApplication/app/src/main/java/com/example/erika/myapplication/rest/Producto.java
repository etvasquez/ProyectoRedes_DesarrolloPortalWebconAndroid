package com.example.erika.myapplication.rest;

public class Producto {
    private int idproducto;
    private String nombre;
    private double preciounitario;
    private int cantidadStock;
    private String fechaemision;
    private String fechaexpiedicion;
    private Categoria idcategoria;
    private Estado idestado;

    public Producto() {
    }

    public Producto(int idproducto, String nombre, double preciounitario, int cantidadStock, String fechaemision, String fechaexpiedicion, Categoria idcategoria, Estado idestado) {
        this.idproducto = idproducto;
        this.nombre = nombre;
        this.preciounitario = preciounitario;
        this.cantidadStock = cantidadStock;
        this.fechaemision = fechaemision;
        this.fechaexpiedicion = fechaexpiedicion;
        this.idcategoria = idcategoria;
        this.idestado = idestado;
    }

    public int getIdproducto() {
        return idproducto;
    }

    public void setIdproducto(int idproducto) {
        this.idproducto = idproducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPreciounitario() {
        return preciounitario;
    }

    public void setPreciounitario(double preciounitario) {
        this.preciounitario = preciounitario;
    }

    public int getCantidadStock() {
        return cantidadStock;
    }

    public void setCantidadStock(int cantidadStock) {
        this.cantidadStock = cantidadStock;
    }

    public String getFechaemision() {
        return fechaemision;
    }

    public void setFechaemision(String fechaemision) {
        this.fechaemision = fechaemision;
    }

    public String getFechaexpiedicion() {
        return fechaexpiedicion;
    }

    public void setFechaexpiedicion(String fechaexpiedicion) {
        this.fechaexpiedicion = fechaexpiedicion;
    }

    public Categoria getIdcategoria() {
        return idcategoria;
    }

    public void setIdcategoria(Categoria idcategoria) {
        this.idcategoria = idcategoria;
    }

    public Estado getIdestado() {
        return idestado;
    }

    public void setIdestado(Estado idestado) {
        this.idestado = idestado;
    }
}
