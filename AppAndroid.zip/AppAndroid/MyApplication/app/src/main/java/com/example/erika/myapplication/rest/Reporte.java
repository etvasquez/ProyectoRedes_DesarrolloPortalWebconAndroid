package com.example.erika.myapplication.rest;

public class Reporte {
    String cantidad = null;
    String nombre = null;

    public Reporte() {
    }

    public Reporte(String cantidad, String nombre) {
        this.cantidad = cantidad;
        this.nombre = nombre;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
