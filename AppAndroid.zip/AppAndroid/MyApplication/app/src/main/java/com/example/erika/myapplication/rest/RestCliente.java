package com.example.erika.myapplication.rest;

import android.content.Context;
import android.util.Base64;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RestCliente {
    public static String puerto;
    private RestCliente() {
    }

    public static <S> S cliente(Class<S> serviceClass, Context context, String username, String password) {
        return configurarRestClient(serviceClass, context, username, password);
    }

    private static <S> S configurarRestClient(Class<S> serviceClass, Context context, String username, String password) {
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient.Builder okHttpClientBuilder = new OkHttpClient.Builder();
        if (username != null && password != null) {
            String credentials = username + ":" + password;
            final String basic = "Basic " + Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
            okHttpClientBuilder.addInterceptor(new Interceptor() {
                @Override
                public Response intercept(Chain chain) throws IOException {
                    Request original = chain.request();
                    Request.Builder requestBuilder = original.newBuilder()
                            .header("Authorization", basic)
                            .header("Accept", "application/json")
                            .method(original.method(), original.body());
                    Request request = requestBuilder.build();
                    return chain.proceed(request);
                }
            });

        }

        String url=puerto+":8080/MainTienda/webresources/get/proveedor/";
        String ISO_DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";

        Gson gson = new GsonBuilder().setDateFormat(ISO_DATE_TIME_FORMAT).create();

        Retrofit retrofit = new Retrofit.Builder().addConverterFactory(GsonConverterFactory.create(gson))
                .baseUrl(url) //
                .client(okHttpClientBuilder.readTimeout(200, TimeUnit.SECONDS).connectTimeout(30, TimeUnit.SECONDS).build()).build();
        return retrofit.create(serviceClass);
    }
}
