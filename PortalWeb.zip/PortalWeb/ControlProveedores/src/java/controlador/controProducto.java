/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import conexion.conexion;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Categoria;
import modelo.EstadoProducto;
import modelo.Producto;
import modelo.Proveedor;
import modelo.productohasproveedor;

/**
 *
 * @author Erika
 */
public class controProducto {

    public static List<productohasproveedor> PresentarProductoClientes() {
        List<productohasproveedor> producpro = new ArrayList<>();
        productohasproveedor pro = null;
        Producto producto = null;
        Proveedor proveedor = null;
        EstadoProducto estado = null;
        Categoria categoria = null;
        try {
            Statement sta = conexion.cb().createStatement();
            String sql = "SELECT p.*, pro.*, e.*, c.*FROM producto p, proveedor pro, proveedor_has_producto pp, "
                    + "estadoproducto e, categoria c WHERE p.idproducto = pp.producto_idproducto AND pro.idproveedor ="
                    + " pp.proveedor_idproveedor AND e.idestadoproducto = p.estadoproducto_idestadoproducto AND "
                    + "c.idcategoria = p.categoria_idcategoria;";
            ResultSet rs = sta.executeQuery(sql);
            while (rs.next()) {
                pro = new productohasproveedor();
                producto = new Producto();
                proveedor = new Proveedor();
                estado = new EstadoProducto();
                categoria = new Categoria();
                producto.setIdproducto(rs.getInt("idproducto"));
                producto.setNombre(rs.getString("nombre"));
                producto.setPreciounitario(rs.getDouble("preciounitario"));
                producto.setCantidadStock(rs.getInt("cantidadStock"));
                proveedor.setNombres(rs.getString("nombres"));
                proveedor.setDireccion(rs.getString("direccion"));
                proveedor.setCorreo(rs.getString("correo"));
                proveedor.setTelefono(rs.getString("telefono"));
                estado.setIdestado(rs.getInt("idestadoproducto"));
                estado.setEstado(rs.getString("estado"));
                categoria.setIdcategoria(rs.getInt("idcategoria"));
                categoria.setTipo(rs.getString("tipo"));
                producto.setIdestado(estado);
                producto.setIdcategoria(categoria);
                pro.setIdproducto(producto);
                pro.setIdproveedor(proveedor);
                producpro.add(pro);
            }
            conexion.db();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return producpro;
    }

    public static ArrayList<Producto> obtenerProductosProveedor(int idProveedor) {
        ArrayList<Producto> producto = new ArrayList<>();
        Producto pro = null;
        EstadoProducto estado = null;
        Categoria categoria = null;
        PreparedStatement ps = null;
        try {
            String sql = "SELECT p.idproducto, p.nombre, p.cantidadStock, e.estado, p.preciounitario FROM producto p, proveedor pro,"
                    + "proveedor_has_producto pp, estadoproducto e WHERE pp.proveedor_idproveedor = ? AND " // HACER JOINS PARA OBTENER CATEGORIA
                    + "pro.idproveedor = ? AND pp.producto_idproducto = p.idproducto AND"
                    + " p.estadoproducto_idestadoproducto = e.idestadoproducto;";
            ps = conexion.cb().prepareStatement(sql);
            ps.setInt(1, idProveedor);
            ps.setInt(2, idProveedor);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                pro = new Producto();
                estado = new EstadoProducto();
                pro.setIdproducto(rs.getInt("idproducto"));
                pro.setNombre(rs.getString("nombre"));
                pro.setCantidadStock(rs.getInt("cantidadStock"));
                // Inicializa obj tipo estado
                estado.setEstado(rs.getString("estado"));
                pro.setIdestado(estado);
                pro.setPreciounitario(rs.getDouble("preciounitario"));

                producto.add(pro);
            }
            conexion.db();
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
        return producto;
    }

    public static List<EstadoProducto> PresentarEstados() {
        List<EstadoProducto> estados = new ArrayList<>();
        EstadoProducto estado = null;
        try {
            Statement sta = conexion.cb().createStatement();
            String sql = "SELECT * FROM estadoproducto;";
            ResultSet rs = sta.executeQuery(sql);
            while (rs.next()) {
                estado = new EstadoProducto();
                estado.setIdestado(rs.getInt("idestadoproducto"));
                estado.setEstado(rs.getString("estado"));
                estados.add(estado);
            }
            conexion.db();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return estados;
    }

    public static List<Categoria> PresentarCategoria() {
        List<Categoria> categorias = new ArrayList<>();
        Categoria categoria = null;
        try {
            Statement sta = conexion.cb().createStatement();
            String sql = "SELECT * FROM categoria order by idcategoria;";
            ResultSet rs = sta.executeQuery(sql);
            while (rs.next()) {
                categoria = new Categoria();
                categoria.setIdcategoria(rs.getInt("idcategoria"));
                categoria.setTipo(rs.getString("tipo"));
                categorias.add(categoria);
            }
            conexion.db();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return categorias;
    }

    public static int idCategoria(String tipo) {
        int categoria = 0;
        try {
            Statement sta = conexion.cb().createStatement();
            String sql = "SELECT idcategoria FROM categoria WHERE tipo ='" + tipo + "';";
            ResultSet rs = sta.executeQuery(sql);
            while (rs.next()) {
                categoria = rs.getInt("idcategoria");
            }
            conexion.db();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return categoria;
    }

    public static int idEstado(String estado) {
        int idestado = 0;
        try {
            Statement sta = conexion.cb().createStatement();
            String sql = "SELECT idestadoproducto FROM estadoproducto WHERE estado ='" + estado + "';";
            ResultSet rs = sta.executeQuery(sql);
            while (rs.next()) {
                idestado = rs.getInt("idestadoproducto");
            }
            conexion.db();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return idestado;
    }

    public static boolean IngresarProducto(Producto pro) {
        boolean bandera = false;
        try {
            String sql = "INSERT INTO producto(nombre,preciounitario,cantidadStock,fechaemision,fechaexpedicion, categoria_idcategoria,estadoproducto_idestadoproducto)"
                    + " VALUES (?,?,?,?,?,?,?);";
            PreparedStatement pst = conexion.cb().prepareStatement(sql);
            pst.setString(1, pro.getNombre());
            pst.setDouble(2, pro.getPreciounitario());
            pst.setInt(3, pro.getCantidadStock());
            pst.setString(4, pro.getFechaemision());
            pst.setString(5, pro.getFechaexpedicion());
            pst.setInt(6, pro.getIdcategoria().getIdcategoria());
            pst.setInt(7, pro.getIdestado().getIdestado());
            int rs = pst.executeUpdate();
            if (rs > 0) {
                bandera = true;
            }
            conexion.db();

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return bandera;
    }

    public static int ObtenerIdProducto() {
        int id = 0;
        try {
            Statement sta = conexion.cb().createStatement();
            String sql = "select idproducto from producto order by idproducto desc limit 1;";
            ResultSet rs = sta.executeQuery(sql);
            while (rs.next()) {
                id = rs.getInt("idproducto");
            }
            conexion.db();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return id;
    }

    public static boolean IngresarProductoProveedor(int proveedor, int producto) {
        boolean bandera = false;
        try {
            String sql = "INSERT INTO proveedor_has_producto(proveedor_idproveedor, producto_idproducto)"
                    + " VALUES (?,?);";
            PreparedStatement pst = conexion.cb().prepareStatement(sql);
            pst.setInt(1, proveedor);
            pst.setInt(2, producto);
            int rs = pst.executeUpdate();
            if (rs > 0) {
                bandera = true;
            }
            conexion.db();

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return bandera;
    }

    public static Producto ObtenerInfoProducto(int idProducto) throws SQLException {
        Producto pro = null;
        EstadoProducto estado = null;
        Categoria cat = null;
        PreparedStatement ps = null;
        try {
            String sql = "SELECT p.idproducto,p.nombre,p.cantidadStock,p.preciounitario,p.fechaemision,p.fechaexpedicion,est.*,cat.*"
                    + " FROM producto p, categoria cat, estadoproducto est "
                    + "WHERE p.idproducto = ? AND p.categoria_idcategoria = cat.idcategoria "
                    + "AND p.estadoproducto_idestadoproducto = est.idestadoproducto";
            ps = conexion.cb().prepareStatement(sql);
            ps.setInt(1, idProducto);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                pro = new Producto();
                estado = new EstadoProducto();
                cat = new Categoria();
                //
                pro.setIdproducto(rs.getInt("idproducto"));
                pro.setNombre(rs.getString("nombre"));
                pro.setCantidadStock(rs.getInt("cantidadStock"));
                pro.setFechaemision(rs.getString("fechaemision"));
                pro.setFechaexpedicion(rs.getString("fechaexpedicion"));
                // Llenar objeto Estado Producto
                estado.setEstado(rs.getString("estado"));
                estado.setIdestado(rs.getInt("idestadoproducto"));
                // Asignar obj al producto
                pro.setIdestado(estado);
                // Llenar objeto Categoria
                cat.setTipo("tipo");
                cat.setIdcategoria(rs.getInt("idcategoria"));
                //Asigna obj al producto
                pro.setIdcategoria(cat);
                pro.setPreciounitario(rs.getDouble("preciounitario"));

            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar conexion y statement..
            conexion.db();
            ps.close();
        }
        return pro;
    }

    public static void EditarInfoProducto(Producto pro) throws Exception {
        PreparedStatement ps = null;
        try {
            String sql = "UPDATE producto SET nombre = ?, preciounitario = ?, cantidadStock = ?, fechaexpedicion = ?, fechaemision = ?,categoria_idcategoria = ?, estadoproducto_idestadoproducto = ?"+
                    " WHERE producto.idproducto = ?";
            ps = conexion.cb().prepareStatement(sql);
            ps.setString(1, pro.getNombre());
            ps.setDouble(2, pro.getPreciounitario());
            ps.setInt(3,pro.getCantidadStock());
            ps.setString(4, pro.getFechaexpedicion());
            ps.setString(5, pro.getFechaemision());
            ps.setInt(6, pro.getIdcategoria().getIdcategoria());
            ps.setInt(7, pro.getIdestado().getIdestado());
            ps.setInt(8, pro.getIdproducto());
            ps.execute();
            
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }finally{
            conexion.db();
            ps.close();
        }
    }
    
    public static void EliminarRelacionProvProd(int idProveedor,int idProducto) throws Exception{
        PreparedStatement ps = null;
        try{
            String sql = "DELETE from proveedor_has_producto WHERE proveedor_has_producto.proveedor_idproveedor = ? "
                    +"AND proveedor_has_producto.producto_idproducto = ?";
            ps = conexion.cb().prepareStatement(sql);
            ps.setInt(1, idProveedor);
            ps.setInt(2, idProducto);
            ps.execute();
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            conexion.db();
            ps.close();
        }
        
    }
    public static void EliminarProducto(int idProducto) throws Exception{
        PreparedStatement ps = null;
        try{
            String sql = "DELETE from producto WHERE producto.idproducto = ?";
            ps = conexion.cb().prepareStatement(sql);
            ps.setInt(1, idProducto);
            ps.execute();
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            conexion.db();
            ps.close();
        }
        
    }
    public static void setState(int id, int state) throws SQLException{
        //1. disponible 2. caducado 3. agotado 
        PreparedStatement ps = null;
        try{
            String sql = "UPDATE producto SET estadoproducto_idestadoproducto = ? WHERE idproducto = ?";
            ps = conexion.cb().prepareStatement(sql);
            ps.setInt(1, state);
            ps.setInt(2,id);
            ps.execute();
        }catch(ClassNotFoundException | SQLException e){
            System.out.println("Err:"+e.getMessage());
        }finally{
            conexion.db();
            ps.close();
        }
    }
}
