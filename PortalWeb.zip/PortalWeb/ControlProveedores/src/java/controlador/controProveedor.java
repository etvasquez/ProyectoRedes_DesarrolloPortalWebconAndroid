/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import conexion.conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Proveedor;

/**
 *
 * @author Erika
 */
public class controProveedor {

    public static Proveedor loguearUsuario(String usuario, String contrasenia) {
        Proveedor p = null;
        try {
            Statement sta = conexion.cb().createStatement();
            String sql = "SELECT * FROM proveedor WHERE usuario = '" + usuario + "';";
            ResultSet rs = sta.executeQuery(sql);
            if (rs.next()) {
                if (rs.getString(8).equals(contrasenia)) {
                    p = new Proveedor(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(7));
                }
            }
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(controProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return p;
    }
    public static boolean ValidarProveedor(String usuario, String contrasenia) {
        boolean p = false;
        try {
            Statement sta = conexion.cb().createStatement();
            String sql = "SELECT * FROM proveedor WHERE usuario = '" + usuario + "';";
            ResultSet rs = sta.executeQuery(sql);
            if (rs.next()) {
                if (rs.getString(8).equals(contrasenia)) {
                    p = true;
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(controProveedor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(controProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return p;
    }
}
