/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.util.*;
import conexion.conexion;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import modelo.Detalle;
import modelo.ItemVenta;
import modelo.Pedido;

/**
 *
 * @author richard
 */
public class controlPedido {

    private static int getLastOrderID() throws SQLException {
        PreparedStatement st = null;
        int lastdID = 0;
        try {
            //Obtenemos el identificador del ultimo detalle creado.
            String sql = "SELECT MAX(id_pedido) as ultimoid FROM `pedidos`";
            st = conexion.cb().prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                lastdID = rs.getInt("ultimoid");
            }

            return lastdID;
        } catch (ClassNotFoundException | SQLException e) {
            return 0;
        } finally {
            conexion.db();
            st.close();
        }

    }

    public static void crearNuevoDetalle(List<ItemVenta> items_detalle) throws SQLException {
        PreparedStatement st = null;
        try {
            int newID = getLastOrderID();
            System.out.println("UltimoID" + newID);
            for (ItemVenta item : items_detalle) {
                String sql = "INSERT into pedido_productos (id_pedido,id_producto,cantidad) VALUES (?,?,?)";
                st = conexion.cb().prepareStatement(sql);
                st.setInt(1, newID);
                st.setInt(2, item.getId_item());
                st.setInt(3, item.getCantidad());
                st.execute();
                //st.clearParameters();
            }

        } catch (SQLException | ClassNotFoundException e) {
            System.err.println("Error:" + e.getMessage());
        } finally {
            st.close();
            conexion.db();
        }

    }

    public static void crearNuevoPedido(Pedido nuevoPedido) throws SQLException {
        PreparedStatement st = null;
        try {
            String sql = "INSERT INTO pedidos(fecha_pedido, nombre_cliente,direccion_cliente,telefono_cliente,metodopago)VALUES (?,?,?,?,?)";
            st = conexion.cb().prepareStatement(sql);
            st.setDate(1, nuevoPedido.getFecha());
            st.setString(2, nuevoPedido.getNombres_cliente());
            st.setString(3, nuevoPedido.getDireccion_cliente());
            st.setString(4, nuevoPedido.getTelefono_cliente());
            st.setString(5, nuevoPedido.getMetodopago());
            st.execute();
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Error:" + e.getMessage());
        } finally {
            st.close();
            conexion.db();

        }
    }
    private static int getActualQuantity(int id){
        PreparedStatement st = null;
        int cant = 0;
        try{
            String sql = "SELECT cantidadStock from producto where idproducto = ?";
            st = conexion.cb().prepareStatement(sql);
            st.setInt(1, id);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                cant = rs.getInt("cantidadStock");
            }
            return cant;
        }catch(Exception e){
            System.err.println("Err:"+e.getMessage());
            return 0;
        }
    }
    public static void updateProductStock(List<ItemVenta> items_detalle) throws SQLException {
        PreparedStatement st = null;
        try {
            for (ItemVenta itemVenta : items_detalle) {
                int cantActual= getActualQuantity(itemVenta.getId_item());
                String sql = "UPDATE producto SET cantidadStock = ? WHERE idproducto = ?";
                st = conexion.cb().prepareStatement(sql);
                st.setInt(1, cantActual - itemVenta.getCantidad());
                st.setInt(2, itemVenta.getId_item());
                st.execute();
            }

        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Err:" + e.getMessage());
        }finally{
            st.close();
            conexion.db();
        }
    }

}
