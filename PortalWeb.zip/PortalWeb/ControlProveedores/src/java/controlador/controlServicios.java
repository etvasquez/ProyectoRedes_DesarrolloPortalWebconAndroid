/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import conexion.conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.EstadoProducto;
import modelo.Producto;

/**
 *
 * @author Erika
 */
public class controlServicios {
    public static ArrayList<Producto> PresentarProducto(int proveedor, String estadoPro){
        ArrayList<Producto> producto = new ArrayList<>();
        Producto pro = null;
        EstadoProducto estado = null;
        try {
            Statement sta = conexion.cb().createStatement();
            
            String sql ="SELECT p.idproducto, p.nombre, p.cantidadStock, e.estado "+
                    "FROM producto p, proveedor pro, proveedor_has_producto pp, estadoproducto e " +
                    "WHERE pp.proveedor_idproveedor = "+proveedor+" AND  pro.idproveedor = "+proveedor+" AND pp.producto_idproducto = p.idproducto " +
                    "AND p.estadoproducto_idestadoproducto = e.idestadoproducto AND e.estado = '"+estadoPro +"'";
            ResultSet rs = sta.executeQuery(sql);
            while (rs.next()) {
                pro = new Producto();
                estado = new EstadoProducto();
                pro.setIdproducto(rs.getInt("idproducto"));
                pro.setNombre(rs.getString("nombre"));
                pro.setCantidadStock(rs.getInt("cantidadStock")); 
                estado.setEstado(rs.getString("estado"));
                pro.setIdestado(estado);
                producto.add(pro);
            }
            conexion.db();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return producto;
    }
    public static String PresentarProductoMenor(int proveedor){
        String producto = null;
        try {
            Statement sta = conexion.cb().createStatement();
            /*
            String sql = "SELECT SUM(p.preciounitario*pp.cantidad) AS total FROM producto p, pedido_productos pp,"
                    + " pedidos pe WHERE pp.id_producto = p.idproducto AND pp.id_pedido = pe.id_pedido GROUP BY "
                    + "pe.id_pedido ORDER BY total ASC LIMIT 1";*/
            String sql = "SELECT p.nombre, php.producto_idproducto as producto, pprod.cantidad "
                    + "from proveedor_has_producto php, pedido_productos pprod, producto p "
                    + "WHERE php.proveedor_idproveedor ="+proveedor+" and pprod.id_producto = php.producto_idproducto "
                    + "and php.producto_idproducto = p.idproducto group by php.producto_idproducto "
                    + "order by producto asc limit 1";
            ResultSet rs = sta.executeQuery(sql);
            while (rs.next()) {
                producto = (rs.getString("nombre"));
            }
            conexion.db();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return producto;
    }
    public static String PresentarProductoMayor(int proveedor){
        String producto = null;
        try {
            Statement sta = conexion.cb().createStatement();
            String sql = "SELECT p.nombre, php.producto_idproducto as producto, pprod.cantidad "
                    + "from proveedor_has_producto php, pedido_productos pprod, producto p "
                    + "WHERE php.proveedor_idproveedor ="+proveedor+" and pprod.id_producto = php.producto_idproducto "
                    + "and php.producto_idproducto = p.idproducto group by php.producto_idproducto "
                    + "order by producto desc limit 1";
            ResultSet rs = sta.executeQuery(sql);
            while (rs.next()) {
                producto = (rs.getString("nombre"));
            }
            conexion.db();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return producto;
    }
    
    public static String PresentarGanancias(int proveedor){
        String producto = null;
        try {
            Statement sta = conexion.cb().createStatement();
            String sql = "SELECT SUM(p.preciounitario*pp.cantidad) AS total FROM producto p, pedido_productos pp, pedidos pe, proveedor_has_producto php "
                    + "WHERE pp.id_producto = p.idproducto AND pp.id_pedido = pe.id_pedido "
                    + "AND php.proveedor_idproveedor ="+proveedor+" GROUP BY pe.id_pedido ORDER BY total DESC LIMIT 1";
            ResultSet rs = sta.executeQuery(sql);
            while (rs.next()) {
                producto = (rs.getString("total"));
            }
            conexion.db();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(controProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return producto;
    }
}
