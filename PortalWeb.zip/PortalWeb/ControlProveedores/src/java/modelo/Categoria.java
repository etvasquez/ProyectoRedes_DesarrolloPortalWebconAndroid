/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Erika
 */
public class Categoria {
    private int idcategoria;
    private String tipo;

    public Categoria() {
    }

    public Categoria(int idcategoria) {
        this.idcategoria = idcategoria;
    }
    
    public Categoria(int idcategoria, String tipo) {
        this.idcategoria = idcategoria;
        this.tipo = tipo;
    }

    public int getIdcategoria() {
        return idcategoria;
    }

    public void setIdcategoria(int idcategoria) {
        this.idcategoria = idcategoria;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    
}
