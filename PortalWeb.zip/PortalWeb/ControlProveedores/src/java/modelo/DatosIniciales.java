/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Erika
 */
public class DatosIniciales {
    Proveedor pro = null;
    ArrayList<Producto> listpro= null;

    public DatosIniciales() {
    }
    public DatosIniciales(Proveedor pro,ArrayList<Producto> listpro) {
        this.pro = pro;
        this.listpro = listpro;
    }

    public Proveedor getPro() {
        return pro;
    }

    public void setPro(Proveedor pro) {
        this.pro = pro;
    }

    public ArrayList<Producto> getListpro() {
        return listpro;
    }

    public void setListpro(ArrayList<Producto> listpro) {
        this.listpro = listpro;
    }
    
}
