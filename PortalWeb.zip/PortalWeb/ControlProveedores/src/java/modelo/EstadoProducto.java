/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Erika
 */
public class EstadoProducto {
    private int idestado;
    private String estado;

    public EstadoProducto() {
    }

    public EstadoProducto(String estado) {
        this.estado = estado;
    }

    public EstadoProducto(int idestado) {
        this.idestado = idestado;
    }
    
    public EstadoProducto(int idestado, String estado) {
        this.idestado = idestado;
        this.estado = estado;
    }

    public int getIdestado() {
        return idestado;
    }

    public void setIdestado(int idestado) {
        this.idestado = idestado;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
}
