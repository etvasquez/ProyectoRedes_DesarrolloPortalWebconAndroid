
package modelo;
public class Producto {
    private int idproducto;
    private String nombre;
    private double preciounitario;
    private int cantidadStock;
    private String fechaemision;
    private String fechaexpedicion;
    private Categoria idcategoria;
    private EstadoProducto idestado;
    public Producto() {
    }



    public Producto(int idproducto, String nombre, double preciounitario, int cantidadStock, String fechaemision, String fechaexpedicion, Categoria idcategoria, EstadoProducto idestado) {
        this.idproducto = idproducto;
        this.nombre = nombre;
        this.preciounitario = preciounitario;
        this.cantidadStock = cantidadStock;
        this.fechaemision = fechaemision;
        this.fechaexpedicion = fechaexpedicion;
        this.idcategoria = idcategoria;
        this.idestado = idestado;
    }
    

    public Producto(String nombre, double preciounitario, int cantidadStock, String fechaemision, 
            String fechaexpiedicion, Categoria idcategoria, EstadoProducto idestado) {
        this.nombre = nombre;
        this.preciounitario = preciounitario;
        this.cantidadStock = cantidadStock;
        this.fechaemision = fechaemision;
        this.fechaexpedicion = fechaexpiedicion;
        this.idcategoria = idcategoria;
        this.idestado = idestado;
    }

    
    public int getIdproducto() {
        return idproducto;
    }

    public void setIdproducto(int idproducto) {
        this.idproducto = idproducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPreciounitario() {
        return preciounitario;
    }

    public void setPreciounitario(double preciounitario) {
        this.preciounitario = preciounitario;
    }

    public int getCantidadStock() {
        return cantidadStock;
    }

    public void setCantidadStock(int cantidadStock) {
        this.cantidadStock = cantidadStock;
    }

    public String getFechaemision() {
        return fechaemision;
    }

    public void setFechaemision(String fechaemision) {
        this.fechaemision = fechaemision;
    }

    public String getFechaexpedicion() {
        return fechaexpedicion;
    }

    public void setFechaexpedicion(String fechaexpiedicion) {
        this.fechaexpedicion = fechaexpiedicion;
    }

    public Categoria getIdcategoria() {
        return idcategoria;
    }

    public void setIdcategoria(Categoria idcategoria) {
        this.idcategoria = idcategoria;
    }

    public EstadoProducto getIdestado() {
        return idestado;
    }

    public void setIdestado(EstadoProducto idestado) {
        this.idestado = idestado;
    }

    @Override
    public String toString() {
        return "Producto{" + "idproducto=" + idproducto + ", nombre=" + nombre + ", preciounitario=" + preciounitario + ", cantidadStock=" + cantidadStock + ", fechaemision=" + fechaemision + ", fechaexpedicion=" + fechaexpedicion + ", idcategoria=" + idcategoria + ", idestado=" + idestado + '}';
    }
    
    
}
