/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Erika
 */
public class Proveedor {

    private int idproveedor;
    private String nombres;
    private String identificador;
    private String direccion;
    private String telefono;
    private String correo;
    private String usuario;
    private String contrasenia;

    public Proveedor() {
    }

    public Proveedor(int idproveedor, String nombres, String identificador, String direccion, String telefono, String correo, String usuario, String contrasenia) {
        this.idproveedor = idproveedor;
        this.nombres = nombres;
        this.identificador = identificador;
        this.direccion = direccion;
        this.telefono = telefono;
        this.correo = correo;
        this.usuario = usuario;
        this.contrasenia = contrasenia;
    }

    public Proveedor(int idproveedor, String nombres, String identificador, String usuario) {
        this.idproveedor = idproveedor;
        this.nombres = nombres;
        this.identificador = identificador;
        this.usuario = usuario;
    }

    public int getIdproveedor() {
        return idproveedor;
    }

    public void setIdproveedor(int idproveedor) {
        this.idproveedor = idproveedor;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getIdentificador() {
        return identificador;
    }

    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

}
