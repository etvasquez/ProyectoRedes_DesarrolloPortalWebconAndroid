/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Erika
 */
public class productohasproveedor {
    private Producto idproducto; //OBJETOS DE TIPO PRODUCTO Y PROVEEDOR 
    private Proveedor idproveedor;

    public productohasproveedor() {
    }

    public productohasproveedor(Producto idproducto, Proveedor idproveedor) {
        this.idproducto = idproducto;
        this.idproveedor = idproveedor;
    }

    public Producto getIdproducto() {
        return idproducto;
    }

    public void setIdproducto(Producto idproducto) {
        this.idproducto = idproducto;
    }

    public Proveedor getIdproveedor() {
        return idproveedor;
    }

    public void setIdproveedor(Proveedor idproveedor) {
        this.idproveedor = idproveedor;
    }
    
}
