/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servelts;

import controlador.controProducto;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import modelo.Categoria;
import modelo.EstadoProducto;
import modelo.Producto;

/**
 *
 * @author Erika
 */
@WebServlet(name = "ControladorProducto", urlPatterns = {"/ControladorProducto"})
public class ControladorProducto extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            boolean banderaPro = false;
            boolean banderaProPro = false;
            Producto pro = null;
            List<Producto> producto = null;
            String mensaje = "Error";
            // Obtiene los parametros del modal
            int idproveedor = Integer.parseInt(request.getParameter("txtproveedor"));
            String nombre = request.getParameter("txtnombre");
            double precio = Double.parseDouble(request.getParameter("txtprecio"));
            int cantidad = Integer.parseInt(request.getParameter("txtcantidad"));
            String datemi = request.getParameter("datemi");
            String datexpi = request.getParameter("datexpi");
            String categoria = request.getParameter("categoria");
            String estado = request.getParameter("estado");
            int idCategoria = controProducto.idCategoria(categoria);
            int idEstado = controProducto.idEstado(estado);
            //Crea un nuevo Objeto tipo Producto
            pro = new Producto(nombre, precio, cantidad, datemi, datexpi, new Categoria(idCategoria), new EstadoProducto(idEstado));
            // Ingresa nuevo producto a BBDD retorna true si todo esta OK.
            banderaPro = controProducto.IngresarProducto(pro);
            int idProducto = controProducto.ObtenerIdProducto();
            // Asigna el id del nuevo producto al proveedor... Retorna True si todo esta OK
            banderaProPro = controProducto.IngresarProductoProveedor(idproveedor, idProducto);
            // Si la asignacion es igual a true, obtiene la session
            if (banderaProPro == true) {
                HttpSession sesion = request.getSession();
                // Vuelve a obtener denuevo todos los productos
                producto = controProducto.obtenerProductosProveedor(idproveedor);
                // Asigna un atributo a la session con el nuevo listado de productos...
                sesion.setAttribute("productos", producto);
                // Redirige al panel de control
                response.sendRedirect("principal.jsp");
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //Leer el parametro del formulario
        String parametro = request.getParameter("instruccion");
        System.out.println(parametro);

        switch (parametro) {
            case "cargar":
                try {
                    cargarProducto(request, response);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            case "actualizarBBDD":
                try {
                    actualizarProducto(request, response);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            case "eliminar":
                try{
                    eliminarProducto(request, response);
                }catch(Exception e){
                    e.printStackTrace();
                }
                break;
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void cargarProducto(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // Leer el id del producto
        int idProveedor = Integer.parseInt(request.getParameter("idProveedor"));
        //int idProveedor = Integer.parseInt(request.getParameter("txtproveedor"));
        int idProducto = Integer.parseInt(request.getParameter("idProducto"));
        // Consultar datos del producto
        Producto objProducto = controProducto.ObtenerInfoProducto(idProducto);
        // Obtener la session
        List<EstadoProducto> estados = controProducto.PresentarEstados();
        List<Categoria> categorias = controProducto.PresentarCategoria();
        request.setAttribute("producto_actualizar", objProducto);
        request.setAttribute("listaCategorias", categorias);
        request.setAttribute("listaEstados", estados);
        request.setAttribute("idProveedor", idProveedor);
        RequestDispatcher miDispatcher = request.getRequestDispatcher("/actualizarProducto.jsp");
        miDispatcher.forward(request, response);

    }

    private void actualizarProducto(HttpServletRequest request, HttpServletResponse response) throws Exception {
        int idProveedor = Integer.parseInt(request.getParameter("idProveedor"));
        int idProducto = Integer.parseInt(request.getParameter("id_producto"));
        String nombre = request.getParameter("txtnombre");
        double precio = Double.parseDouble(request.getParameter("txtprecio"));
        int cantidad = Integer.parseInt(request.getParameter("txtcantidad"));
        String datemi = request.getParameter("datemi");
        String datexpi = request.getParameter("datexpi");
        String categoria = request.getParameter("categoria");
        String estado = request.getParameter("estado");
        int idCategoria = controProducto.idCategoria(categoria);
        int idEstado = controProducto.idEstado(estado);
        //Crea un nuevo Objeto tipo Producto
        Producto pro = new Producto(idProducto, nombre, precio, cantidad, datemi, datexpi, new Categoria(idCategoria), new EstadoProducto(idEstado));
        controProducto.EditarInfoProducto(pro);
        //Actualizar
        HttpSession sesion = request.getSession();
        // Vuelve a obtener denuevo todos los productos
        List<Producto> producto = controProducto.obtenerProductosProveedor(idProveedor);
        // Asigna un atributo a la session con el nuevo listado de productos...
        sesion.setAttribute("productos", producto);
        // Redirige al panel de control
        response.sendRedirect("principal.jsp");

    }

    private void eliminarProducto(HttpServletRequest request, HttpServletResponse response) throws Exception{
        int idProveedor = Integer.parseInt(request.getParameter("idProveedor"));
        int idProducto = Integer.parseInt(request.getParameter("idProducto"));
        controProducto.EliminarRelacionProvProd(idProveedor, idProducto);
        controProducto.EliminarProducto(idProducto);
        //Actualizar
        HttpSession sesion = request.getSession();
        // Vuelve a obtener denuevo todos los productos
        List<Producto> producto = controProducto.obtenerProductosProveedor(idProveedor);
        // Asigna un atributo a la session con el nuevo listado de productos...
        sesion.setAttribute("productos", producto);
        // Redirige al panel de control
        response.sendRedirect("principal.jsp");
        
    }

}
