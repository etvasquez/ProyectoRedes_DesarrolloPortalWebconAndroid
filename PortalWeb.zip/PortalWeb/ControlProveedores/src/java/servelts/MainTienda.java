/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servelts;

import com.google.gson.Gson;
import java.util.*;
import controlador.controProducto;
import java.io.BufferedReader;
import modelo.productohasproveedor;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import modelo.ItemVenta;
import modelo.Producto;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author richard
 */
public class MainTienda extends HttpServlet {

    List<productohasproveedor> producpro = null;

    @Override
    public void init() throws ServletException {
        //producpro = controProducto.PresentarProductoClientes();
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet MainTienda</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet MainTienda at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            cargarProductos(request, response);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<ItemVenta> listaItems = new ArrayList();
        // Obtenemos la data en un String 
        String respuesta = request.getParameter("mijson");
        try {
            // Parseamos ese String to JSONArray
            JSONArray objJson = new JSONArray(respuesta);
            System.out.println(objJson.toString());
            // Recorremos el array
            for (int i = 0; i < objJson.length(); i++) {
                // Creamos un objeto JSON por cada item del array
                JSONObject objTemp = new JSONObject(objJson.optJSONObject(i).toString());
                // Iniciamos las variables Accediendo a sus atributos
                int id = Integer.parseInt(objTemp.getString("id"));
                String nombre = objTemp.getString("nombre");
                Double precio = Double.parseDouble(objTemp.getString("precio"));
                int cantidad = Integer.parseInt(objTemp.getString("cantidad"));
                // Construimos el obj ItemVenta con las variables.
                ItemVenta item = new ItemVenta(id, nombre, precio, cantidad);
                // Aniadimos a la lista cada item.
                listaItems.add(item);
                

            }
            
            System.out.println(listaItems.size());
            System.out.println(listaItems.toString());
            // Quitamos los item repetidos...
            
            /*request.setAttribute("losItems", listaItems);
            RequestDispatcher rd = request.getRequestDispatcher("/carrito.jsp");
            rd.forward(request, response);*/
            HttpSession sesion = request.getSession();
            sesion.setAttribute("losItems", listaItems);
            response.sendRedirect("/MainTienda/carrito.jsp");

        } catch (NumberFormatException | JSONException e) {
            e.printStackTrace();
        }
        /*BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream()));
        String inputLine;
        StringBuffer sb = new StringBuffer();
        while ((inputLine = br.readLine()) != null) {
            sb.append(inputLine);
        }
        br.close();
        System.out.println(sb.toString());*/
 /*try {
            JSONObject obj_JSONObject = new JSONObject(respuesta);
            System.out.println(obj_JSONObject.getString("id"));
            System.out.println(obj_JSONObject.getString("nombre"));
            System.out.println(obj_JSONObject.getString("precio"));
            System.out.println(obj_JSONObject.getString("cantidad"));
            
        } catch (JSONException ex) {
            ex.printStackTrace();
        }*/
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void cargarProductos(HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<productohasproveedor> losProductos = controProducto.PresentarProductoClientes();
        for (productohasproveedor obj : losProductos) {
            int cant = obj.getIdproducto().getCantidadStock();
            int actualState = obj.getIdproducto().getIdestado().getIdestado();
            if(cant == 0 && actualState != 3){
                //System.out.println("Este producto esta agotado: "+obj.getIdproducto().getNombre());
                int state = 3;
                int idAgotado = obj.getIdproducto().getIdproducto();
                controProducto.setState(idAgotado, state);
            }
        }
        producpro = controProducto.PresentarProductoClientes();
        request.setAttribute("losProductos", producpro);
        RequestDispatcher miDispatcher = request.getRequestDispatcher("/index.jsp");
        miDispatcher.forward(request, response);
    }

    /*private void limpiarLista(List<ItemVenta> listado){
       List<ItemVenta> listadob = new ArrayList<ItemVenta>();
        for (int i = 0; i < listado.size(); i++) {
            for (int j = i+1; j < listado.size(); j++) {
                if(listado.get(i).getId_item() == listado.get(j).getId_item()){
                    listado.remove(i);
                }
            }
        }
        
    }*/
}
