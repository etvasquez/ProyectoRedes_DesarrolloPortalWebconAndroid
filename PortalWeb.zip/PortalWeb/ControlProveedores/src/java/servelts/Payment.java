/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servelts;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Pedido;
import controlador.controlPedido;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;
import modelo.Detalle;
import modelo.ItemVenta;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author richard
 */
public class Payment extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Payment</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Payment at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String instruccion = request.getParameter("instruccion");
       
        switch (instruccion) {
            case "cargar_detalle":
                //List listaDetalle = new ArrayList<Detalle>();
                List listaDetalle = new ArrayList<ItemVenta>();
                String respuesta = request.getParameter("mijson");
                try {
                    JSONArray objJson = new JSONArray(respuesta);
                    System.out.println(objJson.toString());
                    for (int i = 0; i < objJson.length(); i++) {
                        JSONObject objTemp = new JSONObject(objJson.optJSONObject(i).toString());
                        int id = objTemp.getInt("id_item");
                        int cantidad = objTemp.getInt("item_quantity");
                        String nombre = objTemp.getString("name");
                        Double precio = Double.parseDouble(objTemp.getString("price"));
                        ItemVenta itv = new ItemVenta(id,nombre,precio,cantidad);
                        listaDetalle.add(itv);
                    }
                    // CARGA A LA SESSION los items
                     HttpSession sesion = request.getSession();
                     sesion.setAttribute("losItems", listaDetalle);
               
                    
                } catch (JSONException e) {

                }
                break;
            case "crear_pedido":
                String nombre_cliente = request.getParameter("nombre_cliente");
                String direccion = request.getParameter("direccion_cliente");
                String telefono = request.getParameter("telefono_cliente");
                String paymethod = request.getParameter("metodopago");
                Pedido nuevoPedido = new Pedido(nombre_cliente, telefono, direccion, paymethod);
                try {
                    controlPedido.crearNuevoPedido(nuevoPedido);
                    
                    // Obtiene los items
                    HttpSession sesion = request.getSession();
                    List detail = (List<ItemVenta>) sesion.getAttribute("losItems");
                    // Los une al pedido
                    controlPedido.crearNuevoDetalle(detail);
                    controlPedido.updateProductStock(detail);
                    sesion.setAttribute("elPedido",nuevoPedido);
                    sesion.setAttribute("elDetalle", detail);
                    
                    response.sendRedirect("/MainTienda/factura.jsp");
                    
                } catch (SQLException e) {
                    System.out.println("Err:" + e.getMessage());
                }
                break;
        }

    }

    private void cargarDetallePedido(ArrayList<Detalle> detallePedido) {

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
