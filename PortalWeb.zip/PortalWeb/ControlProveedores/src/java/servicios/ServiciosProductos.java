/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicios;

import com.google.gson.Gson;
import controlador.controProveedor;
import controlador.controlServicios;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import modelo.DatosIniciales;
import modelo.Producto;
import modelo.Proveedor;
import sun.misc.BASE64Decoder;

/**
 * REST Web Service
 *
 * @author Erika
 */
@Path("get")
public class ServiciosProductos {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of UsuarioVista
     */
    public ServiciosProductos() {
    }

    /**
     * Retrieves representation of an instance of vista.UsuarioVista
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getJson() {
        //TODO return proper representation object
        return "";
    }

    @GET
    @Path("proveedor/{estado}")
    @Produces(MediaType.APPLICATION_JSON)
    public String getProveedor(@HeaderParam("authorization") String authString, @PathParam("estado") String estado) {
        String datos = isUserAuthenticated(authString);
        boolean bandera = false;
        if (datos == null) {
            return "{\"error\":\"User not authenticated\"}";
        } else {
            String[] parts = datos.split(":");
            Gson g = new Gson();
            controProveedor daoprovee = new controProveedor();
            bandera = daoprovee.ValidarProveedor(parts[0], parts[1]);
            if (bandera) {
                Proveedor pro = daoprovee.loguearUsuario(parts[0], parts[1]);
                controlServicios daoproducto = new controlServicios();
                ArrayList<Producto> produc = daoproducto.PresentarProducto(pro.getIdproveedor(), estado);
                DatosIniciales datosLis = new DatosIniciales(pro, produc);
                return g.toJson(datosLis);
            } else {
                return g.toJson("Usuario Invalido");
            }
        }
    }
   
    @GET
    @Path("proveedor/productomas")
    @Produces(MediaType.APPLICATION_JSON)
    public String getProductoMayor(@HeaderParam("authorization") String authString) {
        String datos = isUserAuthenticated(authString);
        boolean bandera = false;
        if (datos == null) {
            return "{\"error\":\"User not authenticated\"}";
        } else {
            String[] parts = datos.split(":");
            Gson g = new Gson();
            controProveedor daoprovee = new controProveedor();
            bandera = daoprovee.ValidarProveedor(parts[0], parts[1]);
            if (bandera) {
                Proveedor pro = daoprovee.loguearUsuario(parts[0], parts[1]);
                controlServicios daoproducto = new controlServicios();
                String resultado = daoproducto.PresentarProductoMayor(pro.getIdproveedor());
                return g.toJson(resultado);
            } else {
                return g.toJson("Usuario Invalido");
            }
        }
    }
    @GET
    @Path("proveedor/productomenos")
    @Produces(MediaType.APPLICATION_JSON)
    public String getProductoMenor(@HeaderParam("authorization") String authString) {
        String datos = isUserAuthenticated(authString);
        boolean bandera = false;
        if (datos == null) {
            return "{\"error\":\"User not authenticated\"}";
        } else {
            String[] parts = datos.split(":");
            Gson g = new Gson();
            controProveedor daoprovee = new controProveedor();
            bandera = daoprovee.ValidarProveedor(parts[0], parts[1]);
            if (bandera) {
                Proveedor pro = daoprovee.loguearUsuario(parts[0], parts[1]);
                controlServicios daoproducto = new controlServicios();
                String resultado = daoproducto.PresentarProductoMenor(pro.getIdproveedor());
                return g.toJson(resultado);
            } else {
                return g.toJson("Usuario Invalido");
            }
        }
    }
    
    @GET
    @Path("proveedor/ganancia")
    @Produces(MediaType.APPLICATION_JSON)
    public String getProductoGanancias(@HeaderParam("authorization") String authString) {
        String datos = isUserAuthenticated(authString);
        boolean bandera = false;
        if (datos == null) {
            return "{\"error\":\"User not authenticated\"}";
        } else {
            String[] parts = datos.split(":");
            Gson g = new Gson();
            controProveedor daoprovee = new controProveedor();
            bandera = daoprovee.ValidarProveedor(parts[0], parts[1]);
            if (bandera) {
                Proveedor pro = daoprovee.loguearUsuario(parts[0], parts[1]);
                controlServicios daoproducto = new controlServicios();
                String resultado = daoproducto.PresentarGanancias(pro.getIdproveedor());
                return g.toJson(resultado);
            } else {
                return g.toJson("Usuario Invalido");
            }
        }
    }
    
    private String isUserAuthenticated(String authString) {

        String decodedAuth = "";
        // Header is in the format "Basic 5tyc0uiDat4"
        // We need to extract data before decoding it back to original string
        String[] authParts = authString.split("\\s+");
        String authInfo = authParts[1];

        // Decode the data back to original string
        byte[] bytes = null;
        try {
            bytes = new BASE64Decoder().decodeBuffer(authInfo);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        decodedAuth = new String(bytes);
        System.out.println(decodedAuth);

        return decodedAuth;
    }
    
//    @POST 
//    @Consumes(MediaType.APPLICATION_JSON)
//    @Path("insertuser")
//    public boolean insertarUsuario(String content) throws ClassNotFoundException, SQLException{
//        //TODO return proper representation object
//        Gson g = new Gson();
//        usuario u = (usuario)g.fromJson(content, usuario.class);
//        CntroladorUsuario dao = new CntroladorUsuario();8    
//        return dao.insertarUsuario(u);
//    }
    /**
     *
     * PUT method for updating or creating an instance of UsuarioVista
     *
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void putJson(String content) {
    }
}
