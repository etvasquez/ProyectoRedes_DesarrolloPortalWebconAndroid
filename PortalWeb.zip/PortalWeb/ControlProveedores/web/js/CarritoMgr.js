/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$(".eliminar").click(function (){
    var li = $(this).closest("li");
    var sp = li.find("span");
    var precioItem = obtenerNumero(sp[3].textContent);
    var cantidadItem = parseInt(sp[0].textContent);
    var precioTotal = obtenerNumero($("#total").text());
    mermarCarrito(cantidadItem);
    mermarTotal(precioTotal,precioItem);
    $(li).remove();
});
// TODO: Arreglar este metodo..
function obtenerNumero(txt){
    var numb = txt.match(/\d./g);
    numb = numb.join("");
    return numb;
}

function mermarCarrito(cant){
    // Items en carrito
    var nroItems = parseInt($("#valor").text()) - cant;
    $("#valor").text(nroItems);
}
function mermarTotal(precioTotal,precioItem){
    var nuevo_total = precioTotal - precioItem;
    //toFixed nos da (n) numeros decimales
    $("#total").text("$"+nuevo_total.toFixed(1));
}


// TODO:Enviar detalle de pedido a la BD siempre y cuando ya tengamos los datos del Cliente.
function Item_Detail(id_item,item_quantity,name,price){
    this.id_item = id_item;
    this.item_quantity = item_quantity;
    this.name = name;
    this.price = price;
    
    
}
var detail = new Array();
$(".btn-comprar").click(function(){
   let id_items = document.getElementsByName('id_item');
   let items_quantity = document.getElementsByClassName('quantity');
   let item_name = document.getElementsByClassName("itemName");
   let item_price = document.getElementsByClassName("price");
    for (var i = 0; i < id_items.length; i++) {
        let id_value = parseInt(id_items[i].value);
        let quantity = parseInt(items_quantity[i].innerHTML);
        let name = item_name[i].innerHTML;
        let price = item_price[i].innerHTML;
        console.log(id_value+"-"+quantity);
        detail.push(new Item_Detail(id_value,quantity,name,price));
    }
    console.log(JSON.stringify(detail));
    var detalleJSON = JSON.stringify(detail);
    $.post('Payment', {
        mijson: detalleJSON,
        instruccion : "cargar_detalle"

    }, function () {
        console.log("ok");
    });
});