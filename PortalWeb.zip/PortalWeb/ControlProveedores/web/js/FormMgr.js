// Cargar dates
$(document).ready(function () {
    var date_input = $('input[name="datemi"]'); //our date input has the name "date"
    var date_input1 = $('input[name="datexpi"]'); //our date input has the name "date"
    var container = $('.bootstrap-iso form').length > 0 ? $('.bootstrap-iso form').parent() : "body";
    var options = {
        format: 'dd/mm/yyyy',
        container: container,
        todayHighlight: true,
        autoclose: true,
    };
    date_input.datepicker(options);
    date_input1.datepicker(options);
});
//Controlar form1
(function () {
    'use strict';

    window.addEventListener('load', function () {
        var form = document.getElementById('needs-validation');
        form.addEventListener('submit', function (event) {
            if (form.checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    }, false);
})();

/* Controlar FORM 2
(function () {
    'use strict';

    window.addEventListener('load', function () {
        var form = document.getElementById('needs-validation2');
        form.addEventListener('submit', function (event) {
            if (form.checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    }, false);
})();*/


/*Desbloquear TextFields*/

// Obtiene el formulario
var form = document.getElementById("needs-validation");
// obtiene el select categoria
var category = form.elements.categoria;
// Asigna la funcion para que se ejecute cuando ocurra algun cambio
category.onchange = function () {
    var f = this.form;
    if (this.selectedIndex === 2) {
        // Si el producto es de tipo Viveres activa las fecha de expedicion y caducidad..
        f.elements.datemi.disabled = false;
        f.elements.datexpi.disabled = false;
    } else {
        f.elements.datemi.disabled = true;
        f.elements.datexpi.disabled = true;
    }
};
// Llamar al evento para que se ejecute..
category.onchange();
