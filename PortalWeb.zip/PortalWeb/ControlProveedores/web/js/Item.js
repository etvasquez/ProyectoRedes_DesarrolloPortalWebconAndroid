/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


export function Item (){
    this.id = null;
    this.nombre = "";
    this.precio = 0.00;
    this.cantidad = null;
    this.categoria = "";
    this.estado = "";
    this.proveedor = null;
}
