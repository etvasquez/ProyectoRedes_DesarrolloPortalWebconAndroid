/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


// Objeto Item
function Item(id, nombre, precio, cantidad, categoria, estado, proveedor) {
    this.id = "";
    this.nombre = "";
    this.precio = "";
    this.cantidad = "";
    this.categoria = "";
    this.estado = "";
    this.proveedor = "";
}
;


var listado_productos = new Array(); // Este Array almacenara los items aniadidos
// Cuando hagamos click en aniadir al carro obtener toda la fila (row)...
$(".comprar").click(function () {
    let rp = false;
    let temp = new Array();
    let itemTemp = new Item();
    var $row = $(this).closest("tr");    // Find the row
    var $tds = $row.find("td"); // Cada parametro del row
    $.each($tds, function () {
        temp.push($(this).text());// a cada parametro lo almacenamos en un array
    });

       
    // Llenamos los atributos del objeto Item
    itemTemp.id = temp[0];
    itemTemp.nombre = temp[1];
    itemTemp.precio = temp[2];
    itemTemp.cantidad = temp[3];
    itemTemp.estado = temp[4];
    itemTemp.categoria = temp[5];
    itemTemp.proveedor = temp[6];
    // Controlamos que no lleve mas de lo que hay en Stock
    var cantidadStock = temp[7];
    

    // Recorre la lista actual y comprueba si es un item repetido y lo sobre escribe.
    for (var i = 0; i < listado_productos.length; i++) {
        if (itemTemp.id === listado_productos[i].id) {
            itemTemp.cantidad = String(parseInt(listado_productos[i].cantidad) + 1);
            itemTemp.precio = String(parseFloat(itemTemp.precio * itemTemp.cantidad));
            if (parseInt(cantidadStock) < parseInt(itemTemp.cantidad)) {
                window.alert("Stock Limitado, nro de items disponibles:" + cantidadStock);
                this.disabled = true;
            } else {
                listado_productos.splice(i, 1, itemTemp);
                addToCartLogo();
            }
            rp = true; //repetido
        }
    }
    /*if (rp === true && parseInt(cantidadStock) < parseInt(itemTemp.cantidad)) {
     window.alert("Item Limitado: "+cantidadStock);
     }*/
    // si no es un item repetido lo aniade normalmente
    if (rp === false) {
        listado_productos.push(itemTemp);
        addToCartLogo();
    }

});

// Enviamos el listado de productos mediante el metodo POST hacia el Servlet 
function mostrarPedido() {
    var pedidoJSON = JSON.stringify(listado_productos);
    console.log(pedidoJSON);
    $.post('MainTienda', {
        mijson: pedidoJSON

    }, function () {
        console.log("ok");
    });



    /*function (responseText) {
     console.log("ok" + responseText);
     });*/
}
 // Se aumenta un item en el icono del carrito
function addToCartLogo(){
    var span_Text = document.getElementById("valor").innerText;
    span_Text++;
    $('#valor').text(span_Text);
}


