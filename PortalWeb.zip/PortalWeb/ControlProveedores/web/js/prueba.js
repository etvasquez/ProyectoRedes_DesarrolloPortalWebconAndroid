/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(window).on("load", function () {
    var form = document.getElementById("needs-validation");
// obtiene el select categoria y estado
    var product_state = form.elements.idEstado;
    var product_category = form.elements.idCategoria;
    
    var category = form.elements.categoria;
    var state = form.elements.estado;

    
    
    var stateindex = product_state.value;
    var categoryindex = product_category.value;
    
    category.selectedIndex = `${categoryindex}`;
    state.selectedIndex = `${stateindex}`;
    
});

